﻿
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace FizzBuzzObjectOriented
{
   public class FizzBuzz
    {
        private string str;

        

        public int LuckyCount { get; set; }
        public int BuzzCount { get; set; }
        public int FizzCount { get; set; }
        public int FizzBuzzVCount { get; set; }
        public int Counter { get; set; }
        public int intCounter { get; set; }
        public string ComputeFizzBuzz(int range, int three , int five)
        {
            string checkThree = range.ToString();

            if (checkThree.Contains("3") == true)
            {
                LuckyCount++;
                return str += "Lucky";
            }
            else if (range % 15 == 0)
            {
                FizzBuzzVCount++;
                return str += "FizzBuzz";
            }
            else if (range % five == 0)
            {
                BuzzCount++;
                return str += "Buzz";
            }
            else if (range % three == 0)
            {
                FizzCount++;
                return str += "Fizz";
            }
            else
            {
                intCounter++;
                return str += range.ToString();
            }
        }
            
    }
}
