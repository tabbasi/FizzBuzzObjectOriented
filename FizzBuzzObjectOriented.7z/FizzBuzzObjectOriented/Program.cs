﻿using System;
using System.Configuration;

namespace FizzBuzzObjectOriented
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int endNumber = Convert.ToInt32(ConfigurationManager.AppSettings.Get("endWith"));
            // Getting 3 from configuration file . 
            int three = Convert.ToInt32(ConfigurationManager.AppSettings.Get("NumberOne"));
            int five = Convert.ToInt32(ConfigurationManager.AppSettings.Get("NumberTwo"));
            string output = "";

            FizzBuzz obj = new FizzBuzz();
            for(int i = 1; i<= endNumber; i ++)
            {
              output=obj.ComputeFizzBuzz(i, three, five);
            }
            Console.WriteLine( output);
            Console.ReadKey();

        }
    }
}
