﻿using System;
using System.Configuration;

namespace FizzBuzzObjectOriented
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int endNumber = Convert.ToInt32(ConfigurationManager.AppSettings.Get("endWith"));
        
            int three = Convert.ToInt32(ConfigurationManager.AppSettings.Get("NumberOne"));
            //int five = Convert.ToInt32(ConfigurationManager.AppSettings.Get("NumberTwo"));
            string output = "";

            FizzBuzz obj = new FizzBuzz();
            for(int i = 1; i<= endNumber; i ++)
            {
              output=obj.ComputeFizzBuzz(i, three);
            }
            Console.WriteLine( output);
            Console.ReadKey();

        }
    }
}
