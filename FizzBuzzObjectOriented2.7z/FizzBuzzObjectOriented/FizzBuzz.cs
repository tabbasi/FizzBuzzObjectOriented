﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FizzBuzzObjectOriented
{
   public class FizzBuzz
    {
        private string str;
        public string ComputeFizzBuzz(int range, int three)
        {
            string checkThree= Convert.ToString(range);

            if (checkThree.Contains("3") == true)
            {
               return str += "Lucky";
            }
            else if (range % 15 == 0)
            {
                return str += "FizzBuzz";
            }
            else if (range % 5 == 0)
            {
                return str += "Buzz";
            }
            else if (range % three == 0)
            {
                return str += "Fizz";
            }
            else
            {
                return str += range.ToString();
            }
        }
            
    }
}
